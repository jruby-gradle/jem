class Thor
  VERSION = "0.19.1"
end
